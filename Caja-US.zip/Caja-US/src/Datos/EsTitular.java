/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import ConexSQL.ConexSQL;
import java.awt.HeadlessException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author menta
 */
public class EsTitular {

    String NumCuenta;
    private String NIF;
    private boolean EsTitular;

    public ArrayList<Cuenta> CuentaListTitu = new ArrayList<>();

    public EsTitular(String NumCuenta, String NIF, boolean EsTitular) {
        this.NumCuenta = NumCuenta;
        this.NIF = NIF;
        this.EsTitular = EsTitular;
    }
//GETTERS Y SETTERS

    public String getNumCuenta() {
        return NumCuenta;
    }

    public void setNumCuenta(String NumCuenta) {
        this.NumCuenta = NumCuenta;
    }

    public String getNIF() {
        return NIF;
    }

    public void setNIF(String NIF) {
        this.NIF = NIF;
    }

    public boolean isEsTitular() {
        return EsTitular;
    }

    public void setEsTitular(boolean EsTitular) {
        this.EsTitular = EsTitular;
    }

//METODOS
    public static EsTitular CrearTitular(String NumCuenta, String UserNIF) {
        ConexSQL cc = new ConexSQL();
        boolean titular = false;
        EsTitular titu = null;
        String respuesta;

        try {

            do {
                respuesta = JOptionPane.showInputDialog("¿Será Titular? S/N");

                if (respuesta.equalsIgnoreCase("S")) {
                    titular = true;
                    cc.msg("Titular añadido");
                } else if (respuesta.equalsIgnoreCase("N")) {
                    cc.msg("Titular  no añadido");
                    titular = false;
                }
            } while (respuesta.isEmpty() || !respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N"));
            titu = new EsTitular(NumCuenta, UserNIF, titular);

        } catch (HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Error al crear" + e.getMessage());
        }
        return titu;
    }

    @Override
    public String toString() {
        String SiNo = "No";
        if (!EsTitular) {
            String Sino = "Si";
        }

        return "\n NIF " + NIF + "\n Número de cuenta " + NumCuenta + "\n Es titular de la cuenta : " + SiNo;
    }

}
