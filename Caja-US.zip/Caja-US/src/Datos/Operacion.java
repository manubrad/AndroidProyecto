/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author menta
 */
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 *
 * @author menta
 */
public class Operacion {

    public enum Tipo {
        R, I, T
    };
    private String CodOper;
    private LocalDate FechRealizacion;
    private double CantInvo;
    private List<String> NumCuentaInv;
    private String IdUsuOper;
    private Tipo tipo;

//CONSTRUCTOR
    public Operacion(String CodOper, LocalDate FechRealizacion, double CantInvo, List<String> NumCuentaInv, String IdUsuOper, String tipo) {
        this.CodOper = CodOper;
        this.FechRealizacion = FechRealizacion;
        this.CantInvo = CantInvo;
        this.NumCuentaInv = NumCuentaInv;
        this.IdUsuOper = IdUsuOper;
        this.tipo = Tipo.valueOf(tipo);;
    }

//GETTERS  Y SETTERS
    public String getCodOper() {
        return CodOper;
    }

    public void setCodOper(String CodOper) {
        this.CodOper = CodOper;
    }

    public LocalDate getFechRealizacion() {
        return FechRealizacion;
    }

    public void setFechRealizacion(LocalDate FechRealizacion) {
        this.FechRealizacion = FechRealizacion;
    }

    public double getCantInvo() {
        return CantInvo;
    }

    public void setCantInvo(double CantInvo) {
        this.CantInvo = CantInvo;
    }

    public List<String> getNumCuentaInv() {
        return NumCuentaInv;
    }

    public void setNumCuentaInv(List<String> NumCuentaInv) {
        this.NumCuentaInv = NumCuentaInv;
    }

    public String getIdUsuOper() {
        return IdUsuOper;
    }

    public void setIdUsuOper(String IdUsuOper) {
        this.IdUsuOper = IdUsuOper;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    //METODOS
    public static Operacion crear(double CantInvo, List<String> Cuentasinv, String IdUsuOper, String tipo) {

        String uuid = UUID.randomUUID().toString().toUpperCase();
        Stream<Character> digit = uuid.chars().mapToObj(i -> (char) i).filter(Character::isDigit).limit(3);
        Stream<Character> alpha = uuid.chars().mapToObj(i -> (char) i).filter(Character::isAlphabetic).limit(3);
        List<Character> collect = Stream.concat(digit, alpha).collect(Collectors.toList());
        Collections.shuffle(collect);
        String CodOper = collect.stream().map(Object::toString).collect(Collectors.joining());
        LocalDate Fechrealizacion = LocalDate.now();

        Operacion op = new Operacion(CodOper, Fechrealizacion, CantInvo, Cuentasinv, IdUsuOper, tipo);

        return op;

    }

    @Override
    public String toString() {
        return "\n Cantidad involucrada " + CantInvo + "\n Numero de cuentas involucrado " + NumCuentaInv.toString() + "\n Usuario : " + IdUsuOper + "\n Tipo de operación : " + tipo;
    }
}
