/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import ConexSQL.ConexSQL;
import java.awt.HeadlessException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.swing.JOptionPane;

/**
 *
 * @author menta
 *
 */
public class Cuenta {

    private String NumCuenta;
    private LocalDate FechCreacion;
    private double Saldo;
    private List<Cuenta> ListaCuentas = new ArrayList<>();

    //CONSTRUCTOR
   

    public Cuenta(String NumCuenta, LocalDate FechCreacion) {
        this.NumCuenta = NumCuenta;
        this.FechCreacion = FechCreacion;
        this.Saldo = 0.0;

    }

    //GETTERS Y SETTERS
    public String getNumCuenta() {
        return NumCuenta;
    }

    public void setNumCuenta(String Numcuenta) {
        this.NumCuenta = Numcuenta;
    }

    public LocalDate getFechCreacion() {
        return FechCreacion;
    }

    public void setFechCreacion(LocalDate FechCreacion) {
        this.FechCreacion = FechCreacion;
    }

    public double getSaldo() {
        return Saldo;
    }

    public void setSaldo(double Saldo) {
        this.Saldo = Saldo;
    }

    //Metodos
    public static Cuenta crear(String NIF) {

        Cuenta c = null;

        try {
            if (NIF.length() > 8 && (NIF.length() < 10) || (NIF.isEmpty())) {
                String uuid = UUID.randomUUID().toString().toUpperCase();
                Stream<Character> digit = uuid.chars().mapToObj(i -> (char) i).filter(Character::isDigit).limit(10);
                Stream<Character> alpha = uuid.chars().mapToObj(i -> (char) i).filter(Character::isAlphabetic).limit(0);
                List<Character> collect = Stream.concat(digit, alpha).collect(Collectors.toList());
                Collections.shuffle(collect);
                String NumeroCuenta = "ES-2100-0488-1234-12" + collect.stream().map(Object::toString).collect(Collectors.joining());
                LocalDate fecha = LocalDate.now();

                c = new Cuenta(NumeroCuenta, fecha);

                JOptionPane.showMessageDialog(null, "Cuenta creada");
            } else {
                JOptionPane.showMessageDialog(null, " Introducir un NIF de 9 números");
            }
        } catch (HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Error al crear cuenta" + e.getMessage());
        }
        return c;
    }

    @Override
    public String toString() {
        return "\n Número de cuenta " + NumCuenta + "\n Fecha de creación " + FechCreacion + "\n Saldo : " + Saldo + "€";
    }

}
