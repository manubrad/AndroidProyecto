/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author menta
 */
public class Usuario {

    private String NIF;
    private String Nombre;
    private String Apellidos;
    private LocalDate año_nacimiento;
    private String Direccion;
    private String email;
    private String Telefono;

    //CONSTRUCTOR
    public Usuario(String NIF, String Nombre, String Apellidos, String año_nacimiento, String Direccion, String email, String Telefono) {
        this.NIF = NIF;
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        this.año_nacimiento = LocalDate.parse(año_nacimiento, f);
        this.Direccion = Direccion;
        this.email = email;
        this.Telefono = Telefono;

    }

    //GETTERS Y SETTERS
    public String getNIF() {
        return NIF;
    }

    public void setNIF(String NIF) {
        this.NIF = NIF;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public LocalDate getAño_nacimiento() {
        return año_nacimiento;
    }

    public void setAño_nacimiento(LocalDate año_nacimiento) {
        this.año_nacimiento = año_nacimiento;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    //METODOS
    static Usuario crear(String NIF, String Nombre, String Apellidos, String año_nacimiento, String Direccion, String email, String Telefono) {

        Usuario user = new Usuario(NIF, Nombre, Apellidos, año_nacimiento, Direccion, email, Telefono);

        return user;

    }

    @Override
    public String toString() {
        return "Usuario NIF=" + NIF + ", Nombre=" + Nombre + ", Apellidos=" + Apellidos + ", a\u00f1o_nacimiento=" + año_nacimiento + ", Direccion=" + Direccion + ", email=" + email + ", Telefono=" + Telefono;
    }

}
