/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexSQL;

import Datos.Cuenta;
import Datos.EsTitular;
import Datos.Operacion;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author menta
 */
public class ConexSQL {

    Connection conn1 = null;

    public ConexSQL() {

        try {
            //RECUERDA: PARA EJECUTAR ESTE CÓDIGO ES NECESARIO TENER mYSQL FUNCIONANDO Y LAS TABLAS Y USUARIOS CREADOS
            String url1 = "jdbc:mysql://localhost:3306/cajaus";
            String user = "root";
            String password = "manolo";
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                msg("Conexión Exitosa con caja US");
            }

        } catch (SQLException ex) {
            msg("Conexión exitosa FALLIDA");

        }
    }

    public void EjecutarSQL(String datos) {
        // CREA UNA CONSULTA SQL INSERT.
        try {

            Statement sta = conn1.createStatement();
            sta.executeUpdate(datos);
            sta.close();
            msg("Operación realizada");

        } catch (SQLException ex) {

            msg("\"ERROR:al hacer un Insert\"");
        }
    }

    public void InsertarCuenta(Cuenta c) {

        try {

            String SQL = "INSERT INTO cuenta " + "VALUES (?, ?, ?)";
            // CREA UNA CONSULTA SQL INSERT.
            PreparedStatement pst = conn1.prepareStatement(SQL);
            pst.setString(1, c.getNumCuenta());
            pst.setDate(2, java.sql.Date.valueOf(c.getFechCreacion()));
            pst.setDouble(3, c.getSaldo());
            pst.execute();

            msg("La cuenta se ha registrado correctamente");

        } catch (SQLException ex) {
            msg("ERROR: en el registro de la cuenta" + ex.getMessage());

        }

    }

    public void InsertarOperacion(Operacion o) {

        try {

            String SQL = "INSERT INTO operacion " + "VALUES (?, ?, ?, ?, ?, ?)";
            // CREA UNA CONSULTA SQL INSERT.
            PreparedStatement pst = conn1.prepareStatement(SQL);
            pst.setString(1, o.getCodOper());
            pst.setString(2, o.getIdUsuOper());
            pst.setString(3, o.getNumCuentaInv().get(0).toString());
            pst.setDouble(4, o.getCantInvo());
            pst.setString(5, o.getTipo().toString());
            pst.setDate(6, java.sql.Date.valueOf(o.getFechRealizacion()));
            pst.execute();

            msg("La operación se ha registrado correctamente");

        } catch (SQLException ex) {
            msg("ERROR: en el registro de la cuenta" + ex.getMessage());

        }
    }

    public void InsertarOperacionTrans(Operacion o) {

        try {

            String SQL = "INSERT INTO operacion " + "VALUES (?, ?, ?, ?, ?, ?)";
            // CREA UNA CONSULTA SQL INSERT.
            PreparedStatement pst = conn1.prepareStatement(SQL);
            pst.setString(1, o.getCodOper());
            pst.setString(2, o.getIdUsuOper());
            pst.setString(3, o.getNumCuentaInv().get(0).toString());
            pst.setDouble(4, o.getCantInvo());
            pst.setString(5, o.getTipo().toString());
            pst.setDate(6, java.sql.Date.valueOf(o.getFechRealizacion()));
            pst.execute();

            msg("La operación se ha registrado correctamente");

        } catch (SQLException ex) {
            msg("ERROR: en el registro de la cuenta" + ex.getMessage());

        }
    }

    public void InsertarTitular(EsTitular t) {

        try {

            String SQL = "INSERT INTO tenercuenta " + "VALUES (?, ?, ?)";
            // CREA UNA CONSULTA SQL INSERT.
            PreparedStatement pst = conn1.prepareStatement(SQL);
            pst.setString(1, t.getNumCuenta());
            pst.setString(2, t.getNIF());
            pst.setBoolean(3, t.isEsTitular());
            pst.execute();

            msg("Estado registrado correctamente");

        } catch (SQLException ex) {
            msg("ERROR: en el registro" + ex.getMessage());

        }
    }

    public void ModificarUser(String NIF) {
        List<String> listaUser = new ArrayList();
        String regisUser = "select NIF from cliente ;";
        String Valor, Campo;
        try {

            Statement st = conn1.createStatement();
            ResultSet user = st.executeQuery(regisUser);

            while (user.next()) {
                listaUser.add(user.getString("NIF"));
            }

            if (validarUsu(NIF)) {

                Campo = JOptionPane.showInputDialog("Escribe su campo");
                Valor = JOptionPane.showInputDialog("Escribe su valor");
                String SQL = "update cliente set " + Campo + "='" + Valor + "' where NIF= '" + NIF + "';";

                EjecutarSQL(SQL);
            } else {
                msg("El usuario no se encuentra registrado");
            }

        } catch (SQLException e) {
            msg(e.getMessage());
        }

    }

    public void AddOrDelTitular(String Ncuenta) {

        try {
            int titular = 0;
            String request;
            String NIF = JOptionPane.showInputDialog("Introduzca su NIF");

            if (validarUsuCuenta(Ncuenta, NIF)) {
                do {
                 
                   
                    request = JOptionPane.showInputDialog("Para añadir pulse A / D Para eliminar titular?");
                    if (request.equalsIgnoreCase("A")) {
                        titular = 1;
                        msg("Titular Añadido");

                    } else if (request.equalsIgnoreCase("D")) {
                        msg("Titular eliminado");

                    }
                  
                } while (request.isEmpty() || !request.equalsIgnoreCase("A") && !request.equalsIgnoreCase("D"));
                

                
                String SQL = "update tenercuenta set Es_titular = '" + titular + "'   where TnumCuenta= '" + Ncuenta + "' and TNIF ='" + NIF + "';";
                EjecutarSQL(SQL);

            } else {
                msg("Revise que sus datos esten bien introducidos");
            }
        } catch (HeadlessException e) {
            msg(e.getMessage());
        }
    }

    public void Cerrar_Conexion() {
        //SE CIERRA LA CONEXIÓN
        try {

            conn1.close();

        } catch (SQLException ex) {
            msg("ERROR AL CERRAR LA CONEXION");
        }

    }

    public void msg(String mensaje) {

        Icon m = new ImageIcon(getClass().getResource("/ConexSQL/cajaus.png"));
        JOptionPane.showMessageDialog(null, mensaje, "msg-cajaus", JOptionPane.INFORMATION_MESSAGE, m);
    }

    public void listarUsuarios() {

        String SQL = "select NIF,Nombre,Apellidos from cliente;";
        try {

            Statement st = conn1.createStatement();
            ResultSet rs = st.executeQuery(SQL);
            List<String> lista = new ArrayList();

            while (rs.next()) {
                lista.add("\n NIF : " + rs.getString("NIF") + " Nombre: " + rs.getString("Nombre") + " Apellidos: " + rs.getString("Apellidos"));

            }
            msg(lista.toString());

        } catch (SQLException e) {
            msg(e.getMessage());

        }
    }

    public void listarCuenta(String NIF) {
        String SQL = "select TnumCuenta, Es_titular from cliente join tenercuenta on cliente.NIF=tenercuenta.TNIF where cliente.NIF like '%" + NIF + "%';";
        List<String> listaCuentas = new ArrayList();
        try {

            Statement st = conn1.createStatement();
            ResultSet rs = st.executeQuery(SQL);

            while (rs.next()) {

                listaCuentas.add("\n Número de cuenta: " + rs.getString("TnumCuenta") + " Titularidad: " + rs.getBoolean("Es_titular"));

            }
            msg(listaCuentas.toString());
        } catch (SQLException e) {
            msg(e.getMessage());

        }

    }

    public void listarOperaciones(String Cuenta) {
        String SQL = "select * from operacion join cuenta on operacion.Num_Involucrado=Cuenta.Numcuenta where numcuenta= " + Cuenta + ";";
        List<String> lista0peraciones = new ArrayList();
        try {

            Statement st = conn1.createStatement();
            ResultSet rs = st.executeQuery(SQL);

            while (rs.next()) {

                lista0peraciones.add("\n Código: " + rs.getString("Cod_Oper") + " Id del usuario: " + rs.getString("IdUsuOper") + " Número Involucrado: " + rs.getString("Num_Involucrado") + " Cantidad: " + rs.getDouble("Cantidad_Involucrada") + " Tipo: " + rs.getString("Tipo") + " Fecha de realización: " + rs.getString("Fech_Realizacion"));

            }
            msg(lista0peraciones.toString());
        } catch (SQLException e) {
            msg(e.getMessage());

        }

    }

    public boolean validarCuenta(String cuenta) {

        String regisUser = "select NumCuenta from Cuenta ;";
        List<String> listaCuenta = new ArrayList();

        boolean resNif = false;
        try {
            Statement st = conn1.createStatement();
            ResultSet user = st.executeQuery(regisUser);

            while (user.next()) {
                listaCuenta.add(user.getString("NumCuenta"));
            }
            if (listaCuenta.contains(cuenta)) {
                resNif = true;
            }
        } catch (SQLException e) {
            msg(e.getMessage());
        }
        return resNif;
    }

    public boolean validarUsuCuenta(String cuenta, String NIF) {

        String regisUser = "select NIF from cliente ;";
        String registro = "select NumCuenta from Cuenta ;";
        List<String> listaUser = new ArrayList();
        List<String> listaCuenta = new ArrayList();
        boolean resCuenta = false;
        boolean resNif = false;
        try {

            Statement st = conn1.createStatement();
            ResultSet user = st.executeQuery(regisUser);

            while (user.next()) {
                listaUser.add(user.getString("NIF"));
            }
        } catch (SQLException e) {
            msg(e.getMessage());
        }

        try {

            Statement st = conn1.createStatement();
            ResultSet regis = st.executeQuery(registro);

            while (regis.next()) {
                listaCuenta.add(regis.getString("NumCuenta"));
            }
        } catch (SQLException e) {
            msg(e.getMessage());

        }

        if (listaCuenta.contains(cuenta)) {
            resCuenta = true;
        } else {
            msg("La cuenta no pertenece a esta entidad");
        }
        if (listaUser.contains(NIF)) {
            resNif = true;
        } else {
            msg("El usuario no pertenece a esta entidad");

        }
        return resCuenta && resNif;

    }

    public boolean validarUsu(String NIF) {
        String regisUser = "select NIF from cliente ;";
        List<String> listaUser = new ArrayList();

        boolean resNif = false;
        try {
            Statement st = conn1.createStatement();
            ResultSet user = st.executeQuery(regisUser);

            while (user.next()) {
                listaUser.add(user.getString("NIF"));
            }
            if (listaUser.contains(NIF)) {
                resNif = true;
            }
        } catch (SQLException e) {
            msg(e.getMessage());
        }
        return resNif;
    }

    public boolean validar(String cuenta, String NIF) {

        String regisUser = "select Es_titular from tenercuenta where TNIF ='" + NIF + "' and TnumCuenta='" + cuenta + "';";
        String registro = "select NumCuenta from Cuenta ;";
        List<String> listaUser = new ArrayList();
        List<String> listaCuenta = new ArrayList();
        boolean resCuenta = false;
        boolean resNif = false;
        try {

            Statement st = conn1.createStatement();
            ResultSet user = st.executeQuery(regisUser);

            while (user.next()) {
                listaUser.add(user.getString("Es_titular"));
            }
        } catch (SQLException e) {
            msg(e.getMessage());
        }

        try {

            Statement st = conn1.createStatement();
            ResultSet regis = st.executeQuery(registro);

            while (regis.next()) {
                listaCuenta.add(regis.getString("NumCuenta"));
            }
        } catch (SQLException e) {
            msg(e.getMessage());

        }

        if (listaCuenta.contains(cuenta)) {
            resCuenta = true;
        } else {
            msg("La cuenta no pertenece a esta entidad");
        }
        if (listaUser.contains("1")) {
            resNif = true;
        } else {
            msg("El usuario no es titular");

        }
        return resCuenta && resNif;

    }

    public void ingresar(String cuenta, String NIF) {

        String SQL = "select saldo,NumCuenta from Cuenta where NumCuenta ='" + cuenta + "';";

        double deposito = 0;
        double ingreso = 0;

        List<String> listaInvolucrada = new ArrayList();

        try {

            Statement st = conn1.createStatement();
            ResultSet rs = st.executeQuery(SQL);

            if (validar(cuenta, NIF)) {

                while (rs.next()) {

                    deposito = rs.getDouble("saldo");
                }
                msg("Su saldo actual es de : " + String.valueOf(deposito) + "€");
                do {
                    ingreso = Double.parseDouble(JOptionPane.showInputDialog("Introduzca la cantidad, a ingresar mínimo 0"));

                } while (ingreso < 0);
                if (ingreso >= 0 || ingreso != 0.) {
                    String ingresarsql = "Update cuenta set saldo = " + (ingreso + deposito) + " where NumCuenta='" + cuenta + "';";
                    EjecutarSQL(ingresarsql);
                    msg("El ingreso se ha hecho correctamente");

                    listaInvolucrada.add(cuenta);
                    Operacion op = Operacion.crear(ingreso, listaInvolucrada, NIF, "I");

                    InsertarOperacion(op);
                }
            } else {
                msg(" Revise el NIF Y Número de cuenta los datos introducidos no se encuentran esta entidad");
            }

        } catch (SQLException ex) {
            msg("Error  " + ex.getMessage());

        }

    }

    public void retirar(String cuenta, String NIF) {

        String SQL = "select saldo,NumCuenta from Cuenta where NumCuenta ='" + cuenta + "';";
        double deposito = 0;
        double retirar = 0;

        List<String> listaInvolucrada = new ArrayList();

        try {

            Statement st = conn1.createStatement();
            ResultSet rs = st.executeQuery(SQL);

            if (validar(cuenta, NIF)) {

                while (rs.next()) {
                    deposito = rs.getDouble("saldo");
                }
                msg("Su saldo actual es de : " + String.valueOf(deposito) + "€");
                do {
                    retirar = Double.parseDouble(JOptionPane.showInputDialog("Introduzca la cantidad a retirar mínimo 0"));
                } while (retirar < 0);
                if (retirar < deposito && retirar > 0 && retirar != 0.) {
                    String retirarsql = "Update cuenta set saldo = " + (deposito - retirar) + " where NumCuenta='" + cuenta + "';";
                    EjecutarSQL(retirarsql);
                    msg("La retirada se ha hecho correctamente");
                    listaInvolucrada.add(cuenta);
                    Operacion op = Operacion.crear(retirar, listaInvolucrada, NIF, "R");
                    InsertarOperacion(op);
                } else {
                    msg("Cantidad insuficiente o mal introducida");
                }

            } else {
                msg(" Revise el NIF Y Número de cuenta los datos introducidos no se encuentran esta entidad");
            }
        } catch (SQLException ex) {
            msg("Debe introducir un número positivo " + ex.getMessage());

        }

    }

    public void retTrans(String cuenta, String NIF) {

        String SQL = "select saldo,NumCuenta from Cuenta where NumCuenta ='" + cuenta + "';";
        double deposito = 0;
        double retirar = 0;
        List<String> listaInvolucrada = new ArrayList();

        try {

            Statement st = conn1.createStatement();
            ResultSet rs = st.executeQuery(SQL);

            if (validar(cuenta, NIF)) {

                while (rs.next()) {
                    deposito = rs.getDouble("saldo");
                }
                msg("Su saldo actual es de : " + String.valueOf(deposito) + "€");
                do {
                    try {
                        retirar = Double.parseDouble(JOptionPane.showInputDialog("Introduzca la cantidad a para la transferencia mayor a 0"));
                    } catch (HeadlessException | NumberFormatException e) {
                        msg("Debe introducir un número positivo");

                    }
                } while (retirar < 0);
                if (retirar < deposito && retirar > 0 && retirar != 0.) {
                    String IngresarSql = "Update cuenta set saldo = " + (deposito - retirar) + " where NumCuenta='" + cuenta + "';";
                    EjecutarSQL(IngresarSql);
                    msg("Se procede a realizar la transferencia");

                    IngreTrans(JOptionPane.showInputDialog("Introduce la cuenta de destino"), retirar);
                    listaInvolucrada.add(cuenta);
                    Operacion op = Operacion.crear(retirar, listaInvolucrada, NIF, "T");
                    InsertarOperacion(op);

                } else {
                    msg("Cantidad insuficiente o mal introducida");
                }

            } else {
                msg(" Revise el NIF Y Número de cuenta los datos introducidos no se encuentran esta entidad");
            }
        } catch (SQLException ex) {
            msg("Debe introducir un número positivo " + ex.getMessage());

        }

    }

    public void IngreTrans(String cuenta, double ingreso) {

        String registro = "select NumCuenta from Cuenta ;";
        String SQL = "select saldo,NumCuenta from Cuenta where NumCuenta ='" + cuenta + "';";
        double deposito = 0;

        List<String> listaCuenta = new ArrayList();
        try {

            Statement st = conn1.createStatement();
            ResultSet regis = st.executeQuery(registro);

            while (regis.next()) {
                listaCuenta.add(regis.getString("NumCuenta"));
            }
        } catch (SQLException e) {
            msg(e.getMessage());

        }

        try {

            Statement st = conn1.createStatement();
            ResultSet rs = st.executeQuery(SQL);

            if (listaCuenta.contains(cuenta)) {

                while (rs.next()) {
                    deposito = rs.getDouble("saldo");
                }

                String ingresarsql = "Update cuenta set saldo = " + (ingreso + deposito) + " where NumCuenta='" + cuenta + "';";
                EjecutarSQL(ingresarsql);
                msg("La Transferencia se ha hecho correctamente");
            } else {
                msg(" Los datos introducidos no son de  una cuenta de esta entidad");
            }
        } catch (SQLException ex) {
            msg("Debe introducir un número positivo " + ex.getMessage());

        }
    }
}
