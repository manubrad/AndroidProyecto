﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace $safeprojectname$
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window

    {

        List<Producto> ListaProducto=new List<Producto>();

        public MainWindow()
        {
            InitializeComponent();

            //
        }

        

       

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

      

        private void Button_Hamburgesa(object sender, RoutedEventArgs e)
        {
            Producto hamburguesa = new Producto(001, 1, 3, 0, 'H',"hamburguesa con queso");
            ListaProducto.Add(hamburguesa);


            dgcProducto.ItemsSource= ListaProducto; 
            Producto p = (Producto) dgcProducto.SelectedItem; 
            String mensaje = string.Format("Bk número{0},codigo {1}, unidades {2}, hamburguesa con queso {3},  {4} Euros,  {5}",
                hamburguesa.E1,hamburguesa.C1,hamburguesa.Ud1,hamburguesa.Descripción,hamburguesa.Precio,hamburguesa.Total);
            MessageBox.Show(mensaje, "El PRO");
            

        }

        private void dgcProducto_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
