﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    internal class Producto
    {
        private int E,Ud,precio,total;
        private char C;
        private String descripción;

        public Producto(int e, int ud, int precio, int total, char c, string descripción)
        {
            E1 = e;
            Ud1 = ud;
            this.Precio = precio;
            this.Total = total;
            C1 = c;
            this.Descripción = descripción;
        }

        public int E1 { get => E; set => E = value; }
        public int Ud1 { get => Ud; set => Ud = value; }
        public int Precio { get => precio; set => precio = value; }
        public int Total { get => total; set => total = value; }
        public char C1 { get => C; set => C = value; }
        public string Descripción { get => descripción; set => descripción = value; }
    }
}
